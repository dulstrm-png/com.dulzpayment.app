const K="dulzpayment_v2";let s=JSON.parse(localStorage.getItem(K)||"null")||{user:null,balance:0,tx:[]};
const $=x=>document.querySelector(x),money=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
function save(){localStorage.setItem(K,JSON.stringify(s))}
function render(){if(!s.user){$("#auth").classList.remove("hide");$("#app").classList.add("hide");return}$("#auth").classList.add("hide");$("#app").classList.remove("hide");$("#name").textContent=s.user.name;$("#saldo").textContent=money(s.balance);$("#tx").innerHTML=s.tx.length?s.tx.slice(0,8).map(x=>`<div class="item"><span>${x.title}<br><small>${new Date(x.date).toLocaleString("id-ID")}</small></span><b>${x.type==="in"?"+":"-"}${money(x.amount)}</b></div>`).join(""):"<p><small>Belum ada transaksi.</small></p>"}
$("#loginTab").onclick=()=>{$("#loginTab").classList.add("active");$("#registerTab").classList.remove("active");$("#login").classList.remove("hide");$("#register").classList.add("hide")}
$("#registerTab").onclick=()=>{$("#registerTab").classList.add("active");$("#loginTab").classList.remove("active");$("#register").classList.remove("hide");$("#login").classList.add("hide")}
$("#register").onsubmit=e=>{e.preventDefault();s.user={name:$("#rn").value,email:$("#re").value,password:$("#rp").value};save();render()}
$("#login").onsubmit=e=>{e.preventDefault();if(s.user&&$("#le").value===s.user.email&&$("#lp").value===s.user.password)render();else alert("Email/password salah atau belum daftar.")}
$("#logout").onclick=()=>{s.user=null;save();render()}
function modal(title,body){$("#modalbody").innerHTML=`<h2>${title}</h2>${body}`;$("#modal").classList.remove("hide")}
$("#close").onclick=()=>$("#modal").classList.add("hide")
$("#topup").onclick=()=>{modal("Top Up Demo",`<input id="amt" type="number" min="1000" placeholder="Nominal"><button id="ok">Tambah Saldo</button>`);$("#ok").onclick=()=>{let a=+$("#amt").value;if(a<1000)return alert("Minimal Rp1.000");s.balance+=a;s.tx.unshift({type:"in",title:"Top Up Demo",amount:a,date:Date.now()});save();$("#modal").classList.add("hide");render()}}
$("#send").onclick=()=>{modal("Kirim Uang",`<input id="to" placeholder="Email penerima"><input id="amt" type="number" min="1000" placeholder="Nominal"><button id="ok">Kirim</button>`);$("#ok").onclick=()=>{let a=+$("#amt").value;if(!$("#to").value||a<1000||a>s.balance)return alert("Data tidak valid / saldo kurang");s.balance-=a;s.tx.unshift({type:"out",title:"Kirim ke "+$("#to").value,amount:a,date:Date.now()});save();$("#modal").classList.add("hide");render()}}
$("#qris").onclick=()=>modal("QRIS",`<p>Scanner QRIS pada prototype ini belum memproses pembayaran nyata.</p><div style="background:#fff;color:#111;height:200px;border-radius:15px;display:grid;place-items:center;font-size:80px">▦</div>`)
$("#pay").onclick=()=>modal("Metode Pembayaran",`<p>QRIS • Virtual Account • E-Wallet • Kartu</p><p>Integrasi payment provider resmi diperlukan untuk transaksi nyata.</p>`)
$("#history").onclick=()=>modal("Riwayat",$("#tx").innerHTML)
render();