# DulzPayment

Prototype payment wallet. GitHub Actions builds a debug APK with Capacitor.

For real payments, use a secure backend and official payment provider; never put secret keys in frontend code.