# DulzPayment

Prototype PWA aplikasi pembayaran bernama **DulzPayment**.

## Fitur demo
- Daftar & login lokal
- Dashboard saldo
- Top up demo
- Kirim saldo demo
- Halaman QRIS / scanner demo
- Pilihan metode pembayaran
- Riwayat transaksi
- PWA installable
- Responsive mobile-first
- GitHub Pages deployment via GitHub Actions

## Penting untuk produksi
Project ini **belum merupakan payment gateway sungguhan**. Saldo dan transaksi hanya disimpan di `localStorage` browser. Untuk menerima uang sungguhan, QRIS, transfer bank, e-wallet, dan pembayaran ke orang lain, backend + database + payment provider resmi diperlukan. Jangan menyimpan secret API/payment key di frontend atau GitHub Pages.

## Upload ke GitHub
1. Buat repository baru.
2. Upload seluruh isi ZIP.
3. Masuk `Settings > Pages`.
4. Pilih `GitHub Actions` sebagai source.
5. Workflow di `.github/workflows/deploy.yml` akan deploy ke GitHub Pages.
