const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const stateKey="dulzpayment_state_v1";
let state=JSON.parse(localStorage.getItem(stateKey)||"null")||{user:null,balance:0,tx:[]};

function save(){localStorage.setItem(stateKey,JSON.stringify(state))}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n)}
function toast(t){let x=$("#toast");x.textContent=t;x.className="show";setTimeout(()=>x.className="",2300)}
function render(){
  if(!state.user){$("#auth").classList.remove("hidden");$("#app").classList.add("hidden");return}
  $("#auth").classList.add("hidden");$("#app").classList.remove("hidden");
  $("#userName").textContent=state.user.name||"Pengguna";
  $("#balance").textContent=rupiah(state.balance);
  const box=$("#transactions");
  if(!state.tx.length){box.innerHTML='<div class="empty">Belum ada transaksi.</div>'}
  else box.innerHTML=state.tx.slice(0,5).map(t=>`<div class="tx"><div class="tx-icon">${t.type==="in"?"↓":"↑"}</div><div class="tx-main"><b>${t.title}</b><small>${new Date(t.date).toLocaleString("id-ID")}</small></div><div class="tx-amt ${t.type==="in"?"plus":"minus"}">${t.type==="in"?"+":"-"}${rupiah(t.amount)}</div></div>`).join("");
}
$$(".tab").forEach(b=>b.onclick=()=>{ $$(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#loginForm").classList.toggle("hidden",b.dataset.auth!=="login");$("#registerForm").classList.toggle("hidden",b.dataset.auth!=="register")});
$("#registerForm").onsubmit=e=>{e.preventDefault();state.user={name:$("#regName").value.trim(),email:$("#regEmail").value.trim(),password:$("#regPassword").value};state.balance=0;state.tx=[];save();toast("Akun berhasil dibuat");render()};
$("#loginForm").onsubmit=e=>{e.preventDefault();if(!state.user)return toast("Belum ada akun. Silakan daftar.");if($("#loginEmail").value!==state.user.email||$("#loginPassword").value!==state.user.password)return toast("Email atau password salah.");toast("Berhasil masuk");render()};
$("#logout").onclick=()=>{state.user=null;save();render()};
$("#toggleBalance").onclick=()=>{$("#balance").classList.toggle("masked");$("#balance").textContent=$("#balance").classList.contains("masked")?"Rp •••••••":rupiah(state.balance)};
$("#topupBtn").onclick=()=>openModal("topup");
$("#allHistory").onclick=()=>openModal("history");
$$("[data-action]").forEach(b=>b.onclick=()=>openModal(b.dataset.action));

function openModal(type){
 const m=$("#modalContent"); let html="";
 if(type==="topup") html=`<h2>Isi Saldo</h2><p>Pada versi demo ini, top up dicatat secara lokal. Untuk produksi, hubungkan ke payment gateway resmi.</p><div class="form-row"><label>Nominal</label><input id="amount" type="number" min="1000" placeholder="Contoh: 50000"></div><button class="primary" id="doTopup">Tambah Saldo Demo</button>`;
 if(type==="send") html=`<h2>Kirim Uang</h2><p>Kirim saldo ke pengguna DulzPayment.</p><div class="form-row"><label>Email / Username penerima</label><input id="recipient" placeholder="@username atau email"></div><div class="form-row"><label>Nominal</label><input id="amount" type="number" min="1000" placeholder="Contoh: 25000"></div><button class="primary" id="doSend">Kirim</button>`;
 if(type==="qris") html=`<h2>Bayar dengan QRIS</h2><p>Scanner QRIS asli membutuhkan integrasi kamera + backend/payment provider. Tampilan ini adalah demo.</p><div class="qr-demo">▦</div><button class="primary" id="fakeScan">Simulasikan Scan QR</button>`;
 if(type==="apps") html=`<h2>Metode Pembayaran</h2><p>Untuk pembayaran nyata, provider seperti QRIS/payment gateway perlu dikonfigurasi di backend.</p><div class="method"><button><b>QRIS</b><small>Scan / tampilkan QR</small></button><button><b>Virtual Account</b><small>Bank transfer</small></button><button><b>E-Wallet</b><small>Provider resmi</small></button><button><b>Card</b><small>Payment processor</small></button></div>`;
 if(type==="history") html=`<h2>Riwayat Transaksi</h2><div class="transactions">${state.tx.length?state.tx.map(t=>`<div class="tx"><div class="tx-icon">${t.type==="in"?"↓":"↑"}</div><div class="tx-main"><b>${t.title}</b><small>${new Date(t.date).toLocaleString("id-ID")}</small></div><div class="tx-amt">${t.type==="in"?"+":"-"}${rupiah(t.amount)}</div></div>`).join(""):'<div class="empty">Belum ada transaksi.</div>'}</div>`;
 m.innerHTML=html;$("#modal").classList.remove("hidden");
 const top=$("#doTopup"); if(top)top.onclick=()=>{let a=Number($("#amount").value);if(a<1000)return toast("Minimal Rp1.000");state.balance+=a;state.tx.unshift({type:"in",title:"Top Up Demo",amount:a,date:Date.now()});save();closeModal();render();toast("Saldo berhasil ditambah (demo)")};
 const send=$("#doSend");if(send)send.onclick=()=>{let a=Number($("#amount").value),r=$("#recipient").value.trim();if(!r||a<1000)return toast("Lengkapi penerima & nominal");if(a>state.balance)return toast("Saldo tidak cukup");state.balance-=a;state.tx.unshift({type:"out",title:"Kirim ke "+r,amount:a,date:Date.now()});save();closeModal();render();toast("Transaksi demo berhasil")};
 const scan=$("#fakeScan");if(scan)scan.onclick=()=>toast("QR terdeteksi — demo saja, tidak ada dana nyata.");
}
function closeModal(){$("#modal").classList.add("hidden")}
$("#closeModal").onclick=closeModal;$("#modal").onclick=e=>{if(e.target.id==="modal")closeModal()};
render();
